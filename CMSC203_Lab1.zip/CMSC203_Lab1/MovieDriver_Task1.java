package Lab1;

import java.util.Scanner;

public class MovieDriver_Task1 {

	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		
		String title, rating;
		
		int ticketsSold;
		
		Movie movie = new Movie();
		
		System.out.println("Enter the name of a movie");
		
		title = keyboard.nextLine();
		
		movie.setTitle(title);
		
		System.out.println("Enter the rating of a movie");
		
		rating = keyboard.nextLine();
		
		movie.setRating(rating);
		
		System.out.println("Enter the number of tickets sold for this movie");
		
		ticketsSold = keyboard.nextInt();
		
		movie.setSoldTickets(ticketsSold);
		
		System.out.print(movie.toString() + "\nGoodbye");
	
	}

}