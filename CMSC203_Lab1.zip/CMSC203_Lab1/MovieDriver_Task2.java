package Lab1;

import java.util.Scanner;

public class MovieDriver_Task2 {

	public static void main(String[] args) 
	{
		
		Scanner keyboard = new Scanner(System.in);
		
		String title, rating, string;
		
		int ticketsSold;
		
		char continueProgram = 'y';
		
		Movie movie = new Movie();
		
		while (continueProgram == 'y')
			
		{
		
			System.out.println("Enter the name of a movie");
		
			title = keyboard.nextLine();
		
			movie.setTitle(title);
		
			System.out.println("Enter the rating of a movie");
		
			rating = keyboard.nextLine();
		
			movie.setRating(rating);
		
			System.out.println("Enter the number of tickets sold for this movie");
		
			ticketsSold = keyboard.nextInt();
		
			movie.setSoldTickets(ticketsSold);
		
			System.out.println(movie.toString());
			
			System.out.println("Do you want to enter another one? (y or n)");
			
			keyboard.nextLine();
			
			string = keyboard.nextLine();
			
			continueProgram = string.charAt(0);
			
			while (!(continueProgram == 'y'))
			{
				if (continueProgram == 'n')
					break;
				else
				{
					System.out.println("Incorrect entry.\nPlease "
					+ "choose either y or n");
					
					string = keyboard.nextLine();

					continueProgram = string.charAt(0);
				}
			}
			
		} 
		
		System.out.println("Goodbye");
		
		keyboard.close();
	
	}
}