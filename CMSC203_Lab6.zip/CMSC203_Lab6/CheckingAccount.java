package Lab6;

public class CheckingAccount extends BankAccount
{
	final static double FEE = 0.15;
	
	public CheckingAccount(String name, double initialAmount)
	{
		super(name, initialAmount);
		
		setAccountNumber(getAccountNumber() + "-10");
		
	}
	
	@Override
	
	public boolean withdraw(double amount)
	{
		boolean completed = false;
		
		amount += FEE;
		
		double balance = super.getBalance();
		
		if (super.withdraw(amount))
		{
			balance -= amount;
			setBalance(balance);
			completed = true;
		}
		
		return completed;
	}
}
