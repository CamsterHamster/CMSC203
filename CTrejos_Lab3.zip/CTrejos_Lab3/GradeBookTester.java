package Lab3;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTester {
	
	private GradeBook score1, score2;

	@BeforeEach
	void setUp() throws Exception {
		score1 = new GradeBook(2);
		score2 = new GradeBook(3);
		score1.addScore(60);
		score1.addScore(90);
		score2.addScore(70);
		score2.addScore(80);
		score2.addScore(90);
		
	}
	@AfterEach
	void tearDown() throws Exception {
		score1 = null;
		score2 = null;	
	}
	
	@Test
	void testAddScore() {
		assertTrue(score1.toString().equals("60.0 90.0 "));
		assertTrue(score2.toString().equals("70.0 80.0 90.0 "));
	}
	
	@Test
	void testGetScoreSize() {
		assertEquals(2, score1.getScoreSize(), .001);
		assertEquals(3, score2.getScoreSize(), .001);
	}
	
	@Test
	void testSum() {
		assertEquals(150, score1.sum(), .0001);
		assertEquals(240, score2.sum(), .0001);
	}

	@Test
	void testMinimum() {
		assertEquals(60, score1.minimum(), .001);
		assertEquals(70, score2.minimum(), .001);
	}


	@Test
	void testFinalScore() {
		assertEquals(90, score1.finalScore(), .001);
		assertEquals(170, score2.finalScore(), .001);
	}

}
